import React, { useState } from 'react';
import { GAME_IMAGES } from '../../types/game';

interface FacebookAdPageProps {
  onBack: () => void;
}

const FacebookAdPage: React.FC<FacebookAdPageProps> = ({ onBack }) => {
  const [copied, setCopied] = useState<string | null>(null);

  const adContent = {
    primaryText: `🎮 Can you solve ALL the puzzles?

Join 10 MILLION+ players worldwide in the most addictive puzzle game of 2024!

✨ 50+ brain-teasing levels
🎁 FREE daily rewards & bonuses
🏆 Compete on global leaderboards
👥 Play with friends & send gifts

Guide Blobby through colorful mazes, collect coins, and become a puzzle master! 

⬇️ Download FREE now and get 500 bonus coins!`,
    
    headline: "BLOBBY - The #1 Puzzle Game!",
    
    description: "Free to play • No WiFi needed • New levels weekly!",
    
    callToAction: "Play Now",
    
    linkUrl: "[YOUR_APP_STORE_LINK]"
  };

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopied(field);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Game
          </button>
          <h1 className="text-xl font-bold text-gray-900">Facebook Ad Creative</h1>
          <div className="w-24" />
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Page Title */}
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Your Blobby Facebook Ad</h2>
          <p className="text-gray-600">Ready-to-use ad creative and copy for your Facebook campaign</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Ad Preview */}
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-4 py-3">
              <h3 className="text-white font-semibold flex items-center gap-2">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                Facebook Ad Preview
              </h3>
            </div>
            
            {/* Simulated Facebook Post */}
            <div className="p-4">
              {/* Page Header */}
              <div className="flex items-center gap-3 mb-3">
                <img 
                  src={GAME_IMAGES.character} 
                  alt="Blobby" 
                  className="w-10 h-10 rounded-full border-2 border-purple-400"
                />
                <div>
                  <div className="font-semibold text-gray-900 flex items-center gap-1">
                    Blobby Games
                    <svg className="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div className="text-xs text-gray-500">Sponsored</div>
                </div>
              </div>

              {/* Primary Text */}
              <div className="text-gray-800 text-sm mb-3 whitespace-pre-line">
                {adContent.primaryText}
              </div>

              {/* Ad Image */}
              <div className="relative rounded-lg overflow-hidden mb-3 border border-gray-200">
                <img 
                  src="https://d64gsuwffb70l.cloudfront.net/6942ba83484103d4cae1c5db_1766001994222_5e6f7b80.png"
                  alt="Blobby Ad Creative"
                  className="w-full aspect-[4/5] object-cover"
                />
              </div>

              {/* Link Preview */}
              <div className="bg-gray-100 rounded-lg overflow-hidden mb-3">
                <div className="p-3">
                  <div className="text-xs text-gray-500 uppercase mb-1">PLAY.GOOGLE.COM</div>
                  <div className="font-semibold text-gray-900">{adContent.headline}</div>
                  <div className="text-sm text-gray-600">{adContent.description}</div>
                </div>
              </div>

              {/* CTA Button */}
              <button className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors">
                {adContent.callToAction}
              </button>

              {/* Engagement Bar */}
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-200 text-gray-500 text-sm">
                <div className="flex items-center gap-1">
                  <div className="flex -space-x-1">
                    <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3zM7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3" />
                      </svg>
                    </div>
                    <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </div>
                  </div>
                  <span>12.4K</span>
                </div>
                <div>847 Comments • 2.1K Shares</div>
              </div>
            </div>
          </div>

          {/* Ad Copy */}
          <div className="space-y-6">
            {/* Primary Text */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 px-4 py-3 flex items-center justify-between">
                <h3 className="text-white font-semibold">Primary Text</h3>
                <button
                  onClick={() => copyToClipboard(adContent.primaryText, 'primary')}
                  className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded-lg text-white text-sm transition-colors flex items-center gap-1"
                >
                  {copied === 'primary' ? (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Copied!
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      Copy
                    </>
                  )}
                </button>
              </div>
              <div className="p-4">
                <pre className="text-gray-800 text-sm whitespace-pre-wrap font-sans bg-gray-50 p-4 rounded-lg">
                  {adContent.primaryText}
                </pre>
              </div>
            </div>

            {/* Headline */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-orange-500 to-yellow-500 px-4 py-3 flex items-center justify-between">
                <h3 className="text-white font-semibold">Headline</h3>
                <button
                  onClick={() => copyToClipboard(adContent.headline, 'headline')}
                  className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded-lg text-white text-sm transition-colors flex items-center gap-1"
                >
                  {copied === 'headline' ? (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Copied!
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      Copy
                    </>
                  )}
                </button>
              </div>
              <div className="p-4">
                <p className="text-gray-800 font-semibold bg-gray-50 p-4 rounded-lg">
                  {adContent.headline}
                </p>
                <p className="text-xs text-gray-500 mt-2">Max 40 characters recommended</p>
              </div>
            </div>

            {/* Description */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-green-500 to-emerald-500 px-4 py-3 flex items-center justify-between">
                <h3 className="text-white font-semibold">Link Description</h3>
                <button
                  onClick={() => copyToClipboard(adContent.description, 'description')}
                  className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded-lg text-white text-sm transition-colors flex items-center gap-1"
                >
                  {copied === 'description' ? (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Copied!
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      Copy
                    </>
                  )}
                </button>
              </div>
              <div className="p-4">
                <p className="text-gray-800 bg-gray-50 p-4 rounded-lg">
                  {adContent.description}
                </p>
                <p className="text-xs text-gray-500 mt-2">Max 30 characters recommended</p>
              </div>
            </div>

            {/* Ad Image Download */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-blue-500 to-cyan-500 px-4 py-3">
                <h3 className="text-white font-semibold">Ad Creative Image</h3>
              </div>
              <div className="p-4">
                <div className="flex items-center gap-4">
                  <img 
                    src="https://d64gsuwffb70l.cloudfront.net/6942ba83484103d4cae1c5db_1766001994222_5e6f7b80.png"
                    alt="Ad Creative Thumbnail"
                    className="w-20 h-24 object-cover rounded-lg border border-gray-200"
                  />
                  <div className="flex-1">
                    <p className="text-gray-800 font-medium mb-1">blobby-facebook-ad.png</p>
                    <p className="text-sm text-gray-500 mb-3">1080 x 1350px (4:5 ratio) - Optimized for Facebook Feed</p>
                    <a
                      href="https://d64gsuwffb70l.cloudfront.net/6942ba83484103d4cae1c5db_1766001994222_5e6f7b80.png"
                      download="blobby-facebook-ad.png"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      Download Image
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Campaign Tips */}
        <div className="mt-10 bg-gradient-to-r from-purple-900 to-pink-900 rounded-xl p-6 text-white">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <svg className="w-6 h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
            Facebook Ad Campaign Tips
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-white/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2">Target Audience</h4>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• Ages 18-45</li>
                <li>• Interest: Mobile games, Puzzle games</li>
                <li>• Behavior: Engaged shoppers</li>
                <li>• Similar to: Candy Crush, Wordle players</li>
              </ul>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2">Best Placements</h4>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• Facebook Feed (Primary)</li>
                <li>• Instagram Feed</li>
                <li>• Instagram Stories</li>
                <li>• Facebook Reels</li>
              </ul>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2">Optimization Goals</h4>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• App Installs (Primary)</li>
                <li>• Link Clicks (Awareness)</li>
                <li>• Video Views (Engagement)</li>
                <li>• Start with $10-20/day budget</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Alternative Ad Variations */}
        <div className="mt-10">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Alternative Ad Copy Variations</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {/* Variation A */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center gap-2 mb-3">
                <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs font-bold rounded">VARIATION A</span>
                <span className="text-gray-500 text-sm">Urgency Focus</span>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg text-sm text-gray-800 mb-3">
                <p className="font-semibold mb-2">⏰ LIMITED TIME: Get 1000 FREE coins!</p>
                <p>Over 10 million players can't be wrong!</p>
                <p className="mt-2">Blobby is the puzzle game that's taking over. Simple to learn, impossible to put down.</p>
                <p className="mt-2">🎯 Challenge your brain<br/>🏆 Beat your friends<br/>🎁 Win daily prizes</p>
                <p className="mt-2 font-semibold">Download now before the offer ends!</p>
              </div>
              <button
                onClick={() => copyToClipboard(`⏰ LIMITED TIME: Get 1000 FREE coins!

Over 10 million players can't be wrong!

Blobby is the puzzle game that's taking over. Simple to learn, impossible to put down.

🎯 Challenge your brain
🏆 Beat your friends
🎁 Win daily prizes

Download now before the offer ends!`, 'varA')}
                className="text-purple-600 hover:text-purple-700 text-sm font-medium flex items-center gap-1"
              >
                {copied === 'varA' ? 'Copied!' : 'Copy this version'}
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </button>
            </div>

            {/* Variation B */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center gap-2 mb-3">
                <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-bold rounded">VARIATION B</span>
                <span className="text-gray-500 text-sm">Social Proof Focus</span>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg text-sm text-gray-800 mb-3">
                <p className="font-semibold mb-2">"Best puzzle game I've played in years!" - Sarah M. ⭐⭐⭐⭐⭐</p>
                <p>See why Blobby has a 4.9 rating with over 500,000 reviews!</p>
                <p className="mt-2">🧩 50+ addictive levels<br/>💰 Earn coins & rewards daily<br/>🌍 Compete globally</p>
                <p className="mt-2">Join the Blobby community today - it's FREE!</p>
              </div>
              <button
                onClick={() => copyToClipboard(`"Best puzzle game I've played in years!" - Sarah M. ⭐⭐⭐⭐⭐

See why Blobby has a 4.9 rating with over 500,000 reviews!

🧩 50+ addictive levels
💰 Earn coins & rewards daily
🌍 Compete globally

Join the Blobby community today - it's FREE!`, 'varB')}
                className="text-green-600 hover:text-green-700 text-sm font-medium flex items-center gap-1"
              >
                {copied === 'varB' ? 'Copied!' : 'Copy this version'}
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-12">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <img src={GAME_IMAGES.character} alt="Blobby" className="w-8 h-8 rounded-full" />
            <span className="text-xl font-bold text-purple-300">BLOBBY</span>
          </div>
          <p className="text-gray-400 text-sm">
            © 2024 Blobby Games. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default FacebookAdPage;
